import { GoogleGenAI } from "@google/genai";
import { Job } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateCoverLetter = async (job: Job, userName: string = "[Seu Nome]", userExperience: string = "Experiência geral na área"): Promise<string> => {
  if (!process.env.API_KEY) {
    return "Erro: Chave de API não configurada. Por favor, configure a API_KEY.";
  }

  try {
    const prompt = `
      Atue como um especialista em RH e carreiras. Escreva uma carta de apresentação profissional e curta para a seguinte vaga de emprego:
      
      Vaga: ${job.title}
      Empresa: ${job.company}
      Descrição da Vaga: ${job.description}
      Requisitos: ${job.requirements.join(', ')}
      
      Candidato: ${userName}
      Resumo da Experiência do Candidato: ${userExperience}
      
      A carta deve ser formal, persuasiva, destacar como o candidato atende aos requisitos e demonstrar entusiasmo pela vaga em Itapipoca. 
      Não invente dados falsos, use espaços reservados como [Telefone] se necessário.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text || "Não foi possível gerar a carta no momento.";
  } catch (error) {
    console.error("Erro ao gerar carta:", error);
    return "Desculpe, houve um erro ao conectar com o assistente de IA. Tente novamente mais tarde.";
  }
};

export const analyzeJobFit = async (job: Job): Promise<string> => {
   if (!process.env.API_KEY) {
    return "Erro: Chave de API não configurada.";
  }

  try {
     const prompt = `
      Analise esta vaga de emprego para um candidato: ${job.title} na empresa ${job.company}.
      Descrição: ${job.description}
      
      Liste 3 dicas curtas e práticas de como se preparar para a entrevista desta vaga específica.
      Seja direto e motivador.
     `;

     const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    
    return response.text || "Análise indisponível.";
  } catch (error) {
      console.error(error);
      return "Erro ao analisar vaga.";
  }
}
