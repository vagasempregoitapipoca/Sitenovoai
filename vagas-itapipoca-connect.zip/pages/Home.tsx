import React from 'react';
import { Users, BellRing, Briefcase } from 'lucide-react';
import { HeroCarousel } from '../components/HeroCarousel';
import { JobCard } from '../components/JobCard';
import { JOB_DATA, CAROUSEL_ITEMS } from '../constants';

export const Home: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <HeroCarousel items={CAROUSEL_ITEMS} />
      
      <main className="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        
        {/* Quick Action Buttons (Like the Google Sites original) */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-12">
          <a href="#" className="flex flex-col items-center justify-center p-6 bg-green-600 rounded-lg shadow text-white hover:bg-green-700 transition-colors text-center group">
            <Users className="h-10 w-10 mb-3 group-hover:scale-110 transition-transform" />
            <span className="font-bold text-lg">Grupo WhatsApp</span>
            <span className="text-xs opacity-80 mt-1">Receba vagas no celular</span>
          </a>
          <a href="#" className="flex flex-col items-center justify-center p-6 bg-blue-500 rounded-lg shadow text-white hover:bg-blue-600 transition-colors text-center group">
             <div className="relative">
                <BellRing className="h-10 w-10 mb-3 group-hover:rotate-12 transition-transform" />
                <span className="absolute top-0 right-0 h-3 w-3 bg-red-500 rounded-full animate-pulse"></span>
             </div>
            <span className="font-bold text-lg">Ativar Alerta</span>
            <span className="text-xs opacity-80 mt-1">Notificações diárias</span>
          </a>
          <a href="#" className="flex flex-col items-center justify-center p-6 bg-purple-600 rounded-lg shadow text-white hover:bg-purple-700 transition-colors text-center group">
            <Briefcase className="h-10 w-10 mb-3 group-hover:scale-110 transition-transform" />
            <span className="font-bold text-lg">Cadastrar Currículo</span>
            <span className="text-xs opacity-80 mt-1">Para empresas verem</span>
          </a>
        </div>

        {/* Section Title */}
        <div className="flex items-center space-x-2 mb-6">
          <div className="h-8 w-1 bg-blue-600 rounded-full"></div>
          <h2 className="text-2xl font-bold text-slate-800">Vagas Recentes em Itapipoca</h2>
        </div>

        {/* Job Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {JOB_DATA.map((job) => (
            <JobCard key={job.id} job={job} />
          ))}
        </div>

        {/* Load More Button */}
        <div className="mt-12 text-center">
          <button className="px-8 py-3 border-2 border-blue-600 text-blue-600 font-bold rounded-full hover:bg-blue-600 hover:text-white transition-all transform hover:-translate-y-1">
            Carregar Mais Vagas
          </button>
        </div>

        {/* Info Section */}
        <div className="mt-16 bg-white rounded-xl shadow-sm p-8 border border-slate-100">
            <h3 className="text-xl font-bold text-slate-800 mb-4">Sobre o Mercado de Trabalho em Itapipoca</h3>
            <p className="text-slate-600 mb-4">
                Itapipoca, conhecida como a "cidade dos três climas", tem um comércio vibrante e em constante crescimento. 
                As principais oportunidades concentram-se no varejo, prestação de serviços, saúde e logística.
            </p>
            <p className="text-slate-600">
                Nosso portal atualiza diariamente vagas para diversos níveis de escolaridade, desde estágio até cargos de gerência.
                Fique atento às atualizações e participe dos nossos grupos para não perder nenhuma oportunidade.
            </p>
        </div>
      </main>
    </div>
  );
};
