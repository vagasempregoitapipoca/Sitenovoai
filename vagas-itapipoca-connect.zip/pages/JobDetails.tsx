import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, MapPin, Building, Calendar, DollarSign, CheckCircle, Sparkles, AlertCircle } from 'lucide-react';
import { JOB_DATA } from '../constants';
import { generateCoverLetter, analyzeJobFit } from '../services/geminiService';
import { Job } from '../types';

export const JobDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [job, setJob] = useState<Job | undefined>(undefined);
  
  // AI States
  const [loadingAI, setLoadingAI] = useState(false);
  const [aiContent, setAiContent] = useState<string | null>(null);
  const [aiMode, setAiMode] = useState<'coverLetter' | 'analysis' | null>(null);

  useEffect(() => {
    const foundJob = JOB_DATA.find((j) => j.id === id);
    setJob(foundJob);
    // Reset AI state when job changes
    setAiContent(null);
    setAiMode(null);
  }, [id]);

  const handleGenerateCoverLetter = async () => {
    if (!job) return;
    setLoadingAI(true);
    setAiMode('coverLetter');
    setAiContent(null);
    const result = await generateCoverLetter(job);
    setAiContent(result);
    setLoadingAI(false);
  };

  const handleAnalyzeJob = async () => {
    if (!job) return;
    setLoadingAI(true);
    setAiMode('analysis');
    setAiContent(null);
    const result = await analyzeJobFit(job);
    setAiContent(result);
    setLoadingAI(false);
  };

  if (!job) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-slate-700">Vaga não encontrada</h2>
          <Link to="/" className="text-blue-600 hover:underline mt-4 block">Voltar para o início</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <Link to="/" className="inline-flex items-center text-slate-500 hover:text-blue-600 mb-6 transition-colors">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar para Vagas
        </Link>

        <div className="bg-white rounded-xl shadow-lg overflow-hidden border border-slate-100">
          <div className="bg-blue-600 p-8 text-white">
            <div className="flex flex-wrap justify-between items-start gap-4">
              <div>
                <h1 className="text-3xl font-bold mb-2">{job.title}</h1>
                <div className="flex items-center text-blue-100 text-lg">
                  <Building className="w-5 h-5 mr-2" />
                  {job.company}
                </div>
              </div>
              <span className="bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full font-semibold text-sm border border-white/30">
                {job.type}
              </span>
            </div>
          </div>

          <div className="p-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="flex items-center text-slate-600 bg-slate-50 p-4 rounded-lg">
                <MapPin className="w-6 h-6 mr-3 text-blue-500" />
                <div>
                  <p className="text-xs text-slate-400 font-bold uppercase">Localização</p>
                  <p className="font-medium">{job.location}</p>
                </div>
              </div>
              <div className="flex items-center text-slate-600 bg-slate-50 p-4 rounded-lg">
                <DollarSign className="w-6 h-6 mr-3 text-green-500" />
                <div>
                  <p className="text-xs text-slate-400 font-bold uppercase">Salário</p>
                  <p className="font-medium">{job.salary || 'A combinar'}</p>
                </div>
              </div>
              <div className="flex items-center text-slate-600 bg-slate-50 p-4 rounded-lg">
                <Calendar className="w-6 h-6 mr-3 text-orange-500" />
                <div>
                  <p className="text-xs text-slate-400 font-bold uppercase">Publicado</p>
                  <p className="font-medium">{job.datePosted}</p>
                </div>
              </div>
            </div>

            <div className="space-y-8">
              <section>
                <h3 className="text-xl font-bold text-slate-800 mb-4 border-b pb-2">Descrição da Vaga</h3>
                <p className="text-slate-600 leading-relaxed whitespace-pre-line">
                  {job.description}
                </p>
              </section>

              <section>
                <h3 className="text-xl font-bold text-slate-800 mb-4 border-b pb-2">Requisitos</h3>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {job.requirements.map((req, index) => (
                    <li key={index} className="flex items-start text-slate-600">
                      <CheckCircle className="w-5 h-5 mr-2 text-green-500 flex-shrink-0 mt-0.5" />
                      <span>{req}</span>
                    </li>
                  ))}
                </ul>
              </section>

              {/* Gemini AI Section */}
              <section className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl p-6 border border-purple-100">
                <div className="flex items-center mb-4 text-purple-800">
                  <Sparkles className="w-6 h-6 mr-2" />
                  <h3 className="text-lg font-bold">Assistente de Carreira IA</h3>
                </div>
                <p className="text-sm text-slate-600 mb-4">
                  Use nossa inteligência artificial para se destacar nesta vaga. Gere uma carta personalizada ou receba dicas de entrevista.
                </p>
                
                <div className="flex flex-wrap gap-3 mb-4">
                  <button 
                    onClick={handleGenerateCoverLetter}
                    disabled={loadingAI}
                    className="bg-purple-600 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-purple-700 transition-colors disabled:opacity-50 flex items-center"
                  >
                    {loadingAI && aiMode === 'coverLetter' ? 'Gerando...' : 'Gerar Carta de Apresentação'}
                  </button>
                  <button 
                    onClick={handleAnalyzeJob}
                    disabled={loadingAI}
                    className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-indigo-700 transition-colors disabled:opacity-50 flex items-center"
                  >
                     {loadingAI && aiMode === 'analysis' ? 'Analisando...' : 'Dicas para Entrevista'}
                  </button>
                </div>

                {/* AI Result Area */}
                {aiContent && (
                  <div className="bg-white p-6 rounded-lg border border-purple-200 shadow-sm animate-fade-in">
                    <h4 className="font-bold text-purple-900 mb-2">
                        {aiMode === 'coverLetter' ? 'Sua Carta Sugerida:' : 'Dicas do Especialista:'}
                    </h4>
                    <div className="whitespace-pre-wrap text-slate-700 text-sm leading-relaxed font-mono bg-slate-50 p-4 rounded border border-slate-200">
                      {aiContent}
                    </div>
                    <button 
                        onClick={() => {navigator.clipboard.writeText(aiContent)}}
                        className="mt-3 text-xs text-purple-600 font-bold hover:underline"
                    >
                        Copiar texto
                    </button>
                  </div>
                )}
                
                {!aiContent && !loadingAI && !process.env.API_KEY && (
                    <div className="flex items-center mt-2 text-amber-600 text-xs bg-amber-50 p-2 rounded">
                        <AlertCircle className="w-4 h-4 mr-1" />
                        <span>Configure a API Key para usar a IA.</span>
                    </div>
                )}
              </section>

              <div className="flex flex-col sm:flex-row gap-4 pt-6 border-t">
                <a 
                  href="https://wa.me/?text=Tenho%20interesse%20na%20vaga" 
                  target="_blank"
                  rel="noreferrer"
                  className="flex-1 bg-green-500 hover:bg-green-600 text-white text-center font-bold py-3 px-8 rounded-lg transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
                >
                  Candidatar via WhatsApp
                </a>
                <button className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-lg transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
                  Enviar Currículo por E-mail
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
