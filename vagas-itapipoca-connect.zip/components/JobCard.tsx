import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Clock, DollarSign, Building } from 'lucide-react';
import { Job } from '../types';

interface JobCardProps {
  job: Job;
}

export const JobCard: React.FC<JobCardProps> = ({ job }) => {
  return (
    <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden border border-slate-100 flex flex-col h-full">
      <div className="p-6 flex-grow">
        <div className="flex justify-between items-start mb-2">
            <span className="inline-block px-2 py-1 text-xs font-semibold tracking-wide text-blue-600 uppercase bg-blue-50 rounded-full">
                {job.type}
            </span>
            <span className="text-xs text-slate-400">{job.datePosted}</span>
        </div>
        <h3 className="text-xl font-bold text-slate-800 mb-1 line-clamp-2">{job.title}</h3>
        <div className="flex items-center text-slate-600 mb-4 text-sm font-medium">
          <Building className="w-4 h-4 mr-1" />
          {job.company}
        </div>
        
        <div className="space-y-2 mb-4">
          <div className="flex items-center text-slate-500 text-sm">
            <MapPin className="w-4 h-4 mr-2 flex-shrink-0" />
            {job.location}
          </div>
          {job.salary && (
            <div className="flex items-center text-green-600 text-sm font-medium">
              <DollarSign className="w-4 h-4 mr-2 flex-shrink-0" />
              {job.salary}
            </div>
          )}
          <div className="flex items-center text-slate-500 text-sm">
            <Clock className="w-4 h-4 mr-2 flex-shrink-0" />
            Período Integral
          </div>
        </div>

        <p className="text-slate-600 text-sm line-clamp-3 mb-4">
          {job.description}
        </p>
      </div>

      <div className="p-4 bg-slate-50 border-t border-slate-100">
        <Link 
          to={`/vaga/${job.id}`} 
          className="block w-full text-center bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded transition-colors"
        >
          Ver Detalhes
        </Link>
      </div>
    </div>
  );
};
