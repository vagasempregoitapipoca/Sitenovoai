import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-800 text-slate-300 py-12 mt-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-white text-lg font-bold mb-4">Vagas Itapipoca</h3>
            <p className="text-sm leading-relaxed">
              O maior portal de oportunidades da região. Conectando talentos a empresas locais desde 2023.
            </p>
          </div>
          <div>
            <h3 className="text-white text-lg font-bold mb-4">Links Rápidos</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Início</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Vagas Recentes</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Política de Privacidade</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Termos de Uso</a></li>
            </ul>
          </div>
          <div>
            <h3 className="text-white text-lg font-bold mb-4">Contato</h3>
            <ul className="space-y-2 text-sm">
              <li>Email: contato@vagasitapipoca.com.br</li>
              <li>WhatsApp: (88) 99999-9999</li>
              <li>Itapipoca, Ceará, Brasil</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-slate-700 mt-8 pt-8 text-center text-xs">
          <p>&copy; {new Date().getFullYear()} Vagas Itapipoca. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
};
